#include<pic.h>
//#include <libpic30.h>

void main()
{
	TRISA = 1;
	TRISC = 1;
	TRISD = 0;
    TRISB=0;
	
	ADCON0 = 0XC0;
	ADCON1 = 0X85;
	while(1)
	{
		if (GO == 0)
		{
			PORTD = ADRESH;
			GO = 1;
		}
		
	}
	
	     float adcval;
    unsigned long Light = 0;
     unsigned long Light1=0;
     unsigned long Light2=0;


adcval=((ADRESH<<8)|(ADRESL));    //store the result
    adcval=(adcval/3)-1;

    float VoltageOutput = 0, ResistanceLDR = 0;
    const float AdcRef = 0.0048828125,      // Adcref = 5/1024
                R3 = 10000,                  // 10kOhm
                Vcc = 5.0,
                Resistance0 = 330000;        // resistance at no light.

    //ADC_Value = SamplingAndConversionADC();                 /*  Sampling  */
    VoltageOutput = ((float) adcval) * AdcRef;

    ResistanceLDR = (VoltageOutput * R3)/(Vcc - VoltageOutput);

    Light = (float)(ResistanceLDR / Resistance0);
    Light1 =  100 - Light*100;
    Light2 = Light1*1000;

    /*  As resistanc decreases with the
     * increase in intensity of light so it is 100 - Light also made it in milli*/
    /* Now light variable has values like this for 6% light it has 6000
       for 80% -> 80,000
       for 90% -> 90,000   and so ON    */

    if (Light2 >= 94000)   // I Switch Off street Light when Light is 94 percent.
        RB0= 0; // You may change according o your design.
    else 
        RB0= 1;


}



