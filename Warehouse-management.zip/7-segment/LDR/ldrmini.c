#include<pic.h>
void main()
{       
	unsigned int a=0; // To store the binary value of the intensity.
	TRISA = 0XFF;
	TRISC = 0XFF;
	TRISB = 0X00;
    TRISD=0;
    PORTD=0;
	ADCON0 = 0X45;   //To select the channel.
	ADCON1 = 0X00;
	while(1)
	{     	
		if (GO == 0)    // Conversion starts.
		{
			a = ADRESH;		
			GO = 1;
            PORTB=a;
            if(a<50)    // considered as daylight.
            {
               RD0=0;
            }
            else
            {
                 if(RC0==1)  // people moving.
                 {
                     RD0=1;
                 }
       	         if(RC0==0)
                 {
                     RD0=0;
                 }
            }
           
		}
	
	}
}
	
	