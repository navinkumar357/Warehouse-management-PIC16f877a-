#include<pic.h>
char num[10] = {0xC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90};
int count = 0;
void count_num()
{
	int count,unit,tenth,count1;
	for(count1=1;count1<=9;count1++)
    {
		for(count=0;count<21;count++)
		{
			unit=count%10;
			tenth=count/10;
			PORTB=num[tenth];
			PORTC=num[unit];
			while(!T0IF);
		}
		PORTD=num[count1];
	}
}

void main()
{
		OPTION_REG = 0x07;  
		INTCON=0xE8;
		TRISB=0X80;
		TRISC=0X00;
		TRISD=0X00;
		TRISA0=0;
		TRISE0=1;
		TRISE1=0;
	    while(1)
		{	
			
			count_num();
}
}
void interrupt isr()
{
	GIE=0;
	T0IF=0;
	count+=1;
	if(count==3)
	{
		count=0;
	}
	if(RBIF==1)
	{
		while(!RB7);
	}
	RBIF=0;
	GIE=1;
}


	

